package com.example.digbot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val REQ = 100
    private lateinit var status: TextView
    private lateinit var live: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            status.text = if (BotAccessibilityService.instance != null)
                "Accessibility: ON ✅" else "Accessibility: OFF ❌"
            live.text = (if (Cfg.running) "BOT CHAL RAHA HAI\n" else "Bot band hai\n") +
                Cfg.status + "\n\n" + Cfg.stats()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 80, 40, 40)
        }
        status = TextView(this).apply { textSize = 16f }
        live = TextView(this).apply { textSize = 14f; setPadding(0, 16, 0, 16) }

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        fun sw(t: String, v: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
            text = t; isChecked = v
            setOnCheckedChangeListener { _, c -> f(c); Cfg.save(this@MainActivity) }
        }
        fun bar(t: String, min: Int, max: Int, cur: Int, f: (Int) -> Unit): LinearLayout {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val label = TextView(this).apply { text = "$t: $cur" }
            val sb = SeekBar(this).apply {
                this.max = max - min
                progress = cur - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        label.text = "$t: ${p + min}"
                        if (fromUser) { f(p + min); Cfg.save(this@MainActivity) }
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            box.addView(label); box.addView(sb)
            return box
        }

        root.addView(status)
        root.addView(btn("1. Accessibility ON karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("2. Bot START") { startBot() })
        root.addView(btn("STOP") {
            startService(Intent(this, ScreenCaptureService::class.java).setAction("STOP"))
        })
        root.addView(live)
        root.addView(sw("Screen par bot ki nazar dikhao (debug)", Cfg.debug) { Cfg.debug = it })
        root.addView(sw("Bachte waqt gold ki taraf jao", Cfg.goldSeek) { Cfg.goldSeek = it })
        root.addView(sw("Game over par 'No Thanks' dabao", Cfg.autoNoThanks) { Cfg.autoNoThanks = it })
        root.addView(bar("Bomb se doori % (zyada = jaldi bachega)", 8, 25, (Cfg.clearance * 100).toInt()) {
            Cfg.clearance = it / 100f
        })
        root.addView(bar("Kitni door tak dekhe % (zyada = pehle react)", 20, 50, (Cfg.lookahead * 100).toInt()) {
            Cfg.lookahead = it / 100f
        })
        root.addView(btn("Seekha hua reset karo (gain/style)") {
            Cfg.gain = 1.0f; Cfg.style = 0; Cfg.save(this)
        })
        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    private fun startBot() {
        if (BotAccessibilityService.instance == null) {
            Toast.makeText(this, "Pehle Accessibility ON karo", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScreenCaptureService::class.java)
                .putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Bot chalu. Ab Dig Down game kholo.", Toast.LENGTH_LONG).show()
        }
    }
}
