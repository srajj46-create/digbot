package com.example.digbot

import android.content.Context

/** Sab settings + live status yahin rehte hain (app aur service dono use karte hain). */
object Cfg {
    @Volatile var clearance = 0.145f   // bomb se kitna door rehna hai (screen width ka %)
    @Volatile var lookahead = 0.35f    // drill ke neeche kitni door tak bomb dekhna (screen height ka %)
    @Volatile var debug = true         // screen par bot ki nazar dikhao
    @Volatile var goldSeek = true      // bachte waqt gold wali lane prefer karo
    @Volatile var autoNoThanks = true  // "Do you want to continue?" par No Thanks dabao
    @Volatile var gain = 1.0f          // seekha hua: swipe ke 1px par drill kitna chalta hai
    @Volatile var style = 0            // swipe ka tareeka (auto badalta hai)

    @Volatile var status = "Bot band hai"
    @Volatile var running = false
    @Volatile var scene: Scene? = null
    @Volatile var lane = -1f
    @Volatile var frames = 0
    @Volatile var swipes = 0
    @Volatile var ok = 0
    @Volatile var cancelled = 0
    @Volatile var moved = 0
    @Volatile var noMove = 0

    fun resetStats() { frames = 0; swipes = 0; ok = 0; cancelled = 0; moved = 0; noMove = 0 }

    fun stats(): String =
        "Frames $frames | Swipes $swipes (ok $ok, cancel $cancelled)\n" +
        "Drill hila: $moved baar, nahi hila: $noMove baar\n" +
        "gain ${"%.2f".format(gain)} | style $style"

    fun load(c: Context) {
        val p = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        clearance = p.getFloat("clearance", clearance)
        lookahead = p.getFloat("lookahead", lookahead)
        debug = p.getBoolean("debug", debug)
        goldSeek = p.getBoolean("goldSeek", goldSeek)
        autoNoThanks = p.getBoolean("autoNoThanks", autoNoThanks)
        gain = p.getFloat("gain", gain)
        style = p.getInt("style", style)
    }

    fun save(c: Context) {
        c.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
            .putFloat("clearance", clearance).putFloat("lookahead", lookahead)
            .putBoolean("debug", debug).putBoolean("goldSeek", goldSeek)
            .putBoolean("autoNoThanks", autoNoThanks)
            .putFloat("gain", gain).putInt("style", style).apply()
    }
}
