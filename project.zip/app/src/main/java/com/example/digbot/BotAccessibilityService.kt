package com.example.digbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class BotAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: BotAccessibilityService? = null }

    private var overlay: DebugOverlay? = null

    override fun onServiceConnected() {
        instance = this
        Cfg.load(this)
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            val v = DebugOverlay(this)
            overlay = v
            wm.addView(v, lp)
        } catch (e: Exception) {
            overlay = null
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            overlay?.let { wm.removeView(it) }
        } catch (e: Exception) { }
        overlay = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun refreshOverlay() { overlay?.postInvalidate() }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { Cfg.ok++ }
            override fun onCancelled(gestureDescription: GestureDescription?) { Cfg.cancelled++ }
        }, null)
    }

    fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y); lineTo(x + 1f, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(g, null, null)
    }
}

/** Screen par bot ki nazar: bomb (magenta gola), drill (hara), safe band (cyan), gold (neela). */
class DebugOverlay(ctx: Context) : View(ctx) {
    private fun stroke(col: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = col
    }
    private val bombP = stroke(Color.rgb(255, 0, 255))
    private val drillP = stroke(Color.rgb(0, 255, 0))
    private val bandP = stroke(Color.rgb(0, 255, 255))
    private val goldP = stroke(Color.rgb(90, 190, 255))
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 34f; setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }

    override fun onDraw(c: Canvas) {
        if (!Cfg.debug) return
        val sc = Cfg.scene ?: return
        val kx = width.toFloat() / sc.w
        val ky = height.toFloat() / sc.h
        c.drawText(Cfg.status, 20f, height * 0.905f, txt)
        if (sc.drillX < 0) return
        val cl = Cfg.clearance * sc.w
        val top = sc.drillY * ky
        val bot = (sc.drillY + Cfg.lookahead * sc.h) * ky
        c.drawLine((sc.drillX - cl) * kx, top, (sc.drillX - cl) * kx, bot, bandP)
        c.drawLine((sc.drillX + cl) * kx, top, (sc.drillX + cl) * kx, bot, bandP)
        c.drawCircle(sc.drillX * kx, sc.drillY * ky, 22f, drillP)
        for (b in sc.bombs) c.drawCircle(b.x * kx, b.y * ky, b.r * kx * 1.4f + 6f, bombP)
        for (g in sc.gold) c.drawCircle(g.x * kx, g.y * ky, g.r * kx * 1.4f + 6f, goldP)
        if (Cfg.lane >= 0f) c.drawLine(Cfg.lane * kx, top - 60f, Cfg.lane * kx, top + 60f, drillP)
    }
}
