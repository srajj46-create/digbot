package com.example.digbot

import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class Blob(val x: Float, val y: Float, val r: Float, val n: Int)

class Scene(
    val w: Int, val h: Int,
    val drillX: Float, val drillY: Float,   // -1 agar drill nahi dikha
    val bombs: List<Blob>, val gold: List<Blob>,
    val gameOver: Boolean
)

object Vision {
    private const val F_GRAY = 1
    private const val F_GOLD = 2
    private const val F_ORANGE = 4
    private const val F_GREEN = 16

    fun analyze(buf: ByteBuffer, rs: Int, ps: Int, w: Int, h: Int): Scene {
        val st = max(2, w / 160)
        val gw = w / st
        val gh = h / st
        val flags = ByteArray(gw * gh)
        var white = 0
        var greenMid = 0

        for (gy in 0 until gh) {
            val rowOff = gy * st * rs
            for (gx in 0 until gw) {
                val o = rowOff + gx * st * ps
                val r = buf.get(o).toInt() and 255
                val g = buf.get(o + 1).toInt() and 255
                val b = buf.get(o + 2).toInt() and 255
                var f = 0
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                if (mx - mn < 22 && mx >= 15 && mx <= 130) f = f or F_GRAY
                if (r > 225 && g in 176..235 && b < 110) f = f or F_GOLD
                if (r > 220 && g in 90..175 && b < 70) f = f or F_ORANGE
                if (r > 235 && g > 235 && b > 235) white++
                if (g > 150 && r < 110 && b < 90) {
                    f = f or F_GREEN
                    if (gy > gh * 0.55 && gy < gh * 0.75) greenMid++
                }
                flags[gy * gw + gx] = f.toByte()
            }
        }

        // 1) Drill: orange pixels ka median (drill screen ke beech-upar rehta hai)
        val xs = ArrayList<Int>()
        val ys = ArrayList<Int>()
        for (gy in (gh * 0.28f).toInt() until (gh * 0.55f).toInt()) {
            for (gx in 0 until gw) {
                if ((flags[gy * gw + gx].toInt() and F_ORANGE) != 0) { xs.add(gx); ys.add(gy) }
            }
        }
        var dX = -1f
        var dY = -1f
        if (xs.size >= 6) {
            xs.sort(); ys.sort()
            dX = xs[xs.size / 2].toFloat() * st
            dY = ys[ys.size / 2].toFloat() * st
        }

        // 2) Bomb / gold blobs
        val dc = 0.075f * w / st
        val expA = (0.785f * dc * dc).toInt()
        val minA = max(6, (expA * 0.2f).toInt())
        val maxA = max(minA + 1, (expA * 3.5f).toInt())
        val y0 = (gh * 0.14f).toInt()
        val y1 = (gh * 0.88f).toInt()

        var bombs = components(flags, gw, gh, F_GRAY, y0, y1, minA, maxA, st)
        if (dX >= 0) {
            // drill ka apna steel tip bomb na samjha jaye
            bombs = bombs.filter { !(abs(it.x - dX) < 0.05f * w && it.y > dY - 0.07f * h && it.y < dY + 0.05f * h) }
        }
        val gold = components(flags, gw, gh, F_GOLD, y0, y1, max(4, minA / 2), maxA * 2, st)

        val gameOver = white > gw * gh * 0.6f && greenMid >= 20
        return Scene(w, h, dX, dY, bombs, gold, gameOver)
    }

    private fun components(
        flags: ByteArray, gw: Int, gh: Int, mask: Int,
        y0: Int, y1: Int, minA: Int, maxA: Int, st: Int
    ): List<Blob> {
        val seen = BooleanArray(gw * gh)
        val q = IntArray(gw * gh)
        val out = ArrayList<Blob>()
        for (gy in y0 until y1) {
            for (gx in 0 until gw) {
                val i0 = gy * gw + gx
                if (seen[i0] || (flags[i0].toInt() and mask) == 0) continue
                var head = 0
                var tail = 0
                q[tail++] = i0
                seen[i0] = true
                var n = 0
                var sx = 0L
                var sy = 0L
                var minX = gx; var maxX = gx; var minY = gy; var maxY = gy
                while (head < tail) {
                    val i = q[head++]
                    val cx = i % gw
                    val cy = i / gw
                    n++; sx += cx; sy += cy
                    if (cx < minX) minX = cx
                    if (cx > maxX) maxX = cx
                    if (cy < minY) minY = cy
                    if (cy > maxY) maxY = cy
                    if (cx > 0) {
                        val j = i - 1
                        if (!seen[j] && (flags[j].toInt() and mask) != 0) { seen[j] = true; q[tail++] = j }
                    }
                    if (cx < gw - 1) {
                        val j = i + 1
                        if (!seen[j] && (flags[j].toInt() and mask) != 0) { seen[j] = true; q[tail++] = j }
                    }
                    if (cy > y0) {
                        val j = i - gw
                        if (!seen[j] && (flags[j].toInt() and mask) != 0) { seen[j] = true; q[tail++] = j }
                    }
                    if (cy < y1 - 1) {
                        val j = i + gw
                        if (!seen[j] && (flags[j].toInt() and mask) != 0) { seen[j] = true; q[tail++] = j }
                    }
                }
                if (n < minA || n > maxA) continue
                val bw = maxX - minX + 1
                val bh = maxY - minY + 1
                val asp = bw.toFloat() / bh
                if (asp < 0.5f || asp > 2.0f) continue
                out.add(Blob(sx.toFloat() / n * st, sy.toFloat() / n * st, (bw + bh) / 4f * st, n))
            }
        }
        return out
    }
}
