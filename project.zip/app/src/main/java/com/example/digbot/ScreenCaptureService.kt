package com.example.digbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private class SwipeStyle(val ms: Long, val fromDrill: Boolean)

private val STYLES = arrayOf(
    SwipeStyle(120, true), SwipeStyle(220, true), SwipeStyle(400, true),
    SwipeStyle(160, false), SwipeStyle(400, false)
)

private class Pend(val startX: Float, val dir: Int, val px: Float, val t: Long)

class ScreenCaptureService : Service() {
    private val S = 2                       // capture half resolution
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val thread = HandlerThread("digbot").apply { start() }
    private var fullW = 0
    private var fullH = 0

    private var lastProc = 0L
    private var lastSwipe = 0L
    private var lastTap = 0L
    private var goSince = 0L
    private var fails = 0
    private var pend: Pend? = null

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        showForeground()
        Cfg.load(this)
        Cfg.resetStats()
        val code = intent.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data") ?: run { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(thread.looper))
        startCapture()
        Cfg.running = true
        Cfg.status = "Bot chal raha hai. Game kholo."
        return START_NOT_STICKY
    }

    private fun showForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "DigBot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bot")
            .setContentTitle("DigBot chal raha hai")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        fullW = dm.widthPixels
        fullH = dm.heightPixels
        val rw = fullW / S
        val rh = fullH / S
        reader = ImageReader.newInstance(rw, rh, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "digbot", rw, rh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try { process(img, rw, rh) } catch (e: Exception) { Cfg.status = "Error: ${e.message}" } finally { img.close() }
        }, Handler(thread.looper))
    }

    private fun process(img: Image, w: Int, h: Int) {
        val now = SystemClock.uptimeMillis()
        if (now - lastProc < 40) return
        lastProc = now

        val p = img.planes[0]
        val sc = Vision.analyze(p.buffer, p.rowStride, p.pixelStride, w, h)
        Cfg.scene = sc
        Cfg.frames++
        val acc = BotAccessibilityService.instance
        val sF = fullW.toFloat() / w

        // ---- Game over / Revive screen ----
        if (sc.gameOver) {
            if (goSince == 0L) goSince = now
            Cfg.status = "Game over screen"
            if (Cfg.autoNoThanks && now - goSince > 2200 && now - lastTap > 2500) {
                acc?.tap(fullW * 0.5f, fullH * 0.787f)
                lastTap = now
                Cfg.status = "No Thanks dabaya"
            }
            Cfg.lane = -1f
            acc?.refreshOverlay()
            return
        }
        goSince = 0L

        if (sc.drillX < 0) {
            Cfg.status = "Drill nahi dikha (game screen?)"
            Cfg.lane = -1f
            acc?.refreshOverlay()
            return
        }

        // ---- Seekho: pichla swipe se drill kitna hila? ----
        val pd = pend
        if (pd != null && now - pd.t > 380) {
            val movedPx = (sc.drillX * sF - pd.startX) * pd.dir
            if (movedPx > 0.02f * fullW) {
                val g = (movedPx / pd.px).coerceIn(0.2f, 3f)
                Cfg.gain = 0.6f * Cfg.gain + 0.4f * g
                fails = 0
                Cfg.moved++
            } else {
                fails++
                Cfg.noMove++
                if (fails >= 3) {
                    Cfg.style = (Cfg.style + 1) % STYLES.size
                    fails = 0
                }
            }
            pend = null
        }

        // ---- Khatra napo ----
        val cl = Cfg.clearance * w
        val lookPx = Cfg.lookahead * h
        val near = 0.10f * h

        fun danger(lane: Float): Float {
            var d = 0f
            for (b in sc.bombs) {
                val dy = b.y - sc.drillY
                if (dy < -0.06f * h || dy > lookPx) continue
                if (abs(b.x - lane) < cl) {
                    d += if (dy < near) 1f else max(0.3f, 1f - (dy - near) / (lookPx - near) * 0.7f)
                }
            }
            return d
        }

        val cur = danger(sc.drillX)
        if (cur <= 0f) {
            Cfg.lane = -1f
            Cfg.status = "Safe | bombs ${sc.bombs.size}"
            acc?.refreshOverlay()
            return
        }
        if (now - lastSwipe < 280) { acc?.refreshOverlay(); return }

        // ---- Sabse safe lane chuno ----
        var best = sc.drillX
        var bestC = Float.MAX_VALUE
        var lane = 0.08f * w
        while (lane <= 0.92f * w) {
            var c = 10f * danger(lane) + 0.8f * abs(lane - sc.drillX) / w
            val lo = min(lane, sc.drillX) - 0.6f * cl
            val hi = max(lane, sc.drillX) + 0.6f * cl
            if (abs(lane - sc.drillX) > 0.02f * w) {
                for (b in sc.bombs) {
                    val dy = b.y - sc.drillY
                    if (dy > -0.06f * h && dy < 0.12f * h && b.x > lo && b.x < hi) c += 4f
                }
            }
            if (Cfg.goldSeek) {
                for (g in sc.gold) {
                    val dy = g.y - sc.drillY
                    if (dy > 0.02f * h && dy < lookPx && abs(g.x - lane) < 0.06f * w) c -= 0.35f
                }
            }
            if (c < bestC) { bestC = c; best = lane }
            lane += 0.025f * w
        }

        val mv = best - sc.drillX
        if (abs(mv) < 0.02f * w) { acc?.refreshOverlay(); return }

        // ---- Swipe bhejo ----
        val dir = if (mv > 0) 1 else -1
        val st = STYLES[Cfg.style % STYLES.size]
        val px = (abs(mv) * sF / Cfg.gain).coerceIn(0.06f * fullW, 0.5f * fullW)
        var sx = if (st.fromDrill) sc.drillX * sF else fullW / 2f
        val lo = 0.05f * fullW + (if (dir < 0) px else 0f)
        val hi = 0.95f * fullW - (if (dir > 0) px else 0f)
        sx = sx.coerceIn(lo, hi)
        val sy = fullH * 0.72f
        acc?.swipe(sx, sy, sx + dir * px, sy, st.ms)

        pend = Pend(sc.drillX * sF, dir, px, now)
        lastSwipe = now
        Cfg.lane = best
        Cfg.swipes++
        Cfg.status = "Bomb! ${if (dir > 0) "right" else "left"} swipe"
        acc?.refreshOverlay()
    }

    override fun onDestroy() {
        Cfg.running = false
        Cfg.status = "Bot band hai"
        Cfg.save(this)
        display?.release()
        reader?.close()
        projection?.stop()
        thread.quitSafely()
        super.onDestroy()
    }
}
