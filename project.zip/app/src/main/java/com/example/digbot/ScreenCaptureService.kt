package com.example.digbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Log
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** ---- TUNING: yahin se sab kuch adjust hoga ---- */
object Cfg {
    const val SCALE = 2                 // capture half resolution
    const val STEP = 3                  // har 3rd pixel check (half-res me)
    const val DRILL_Y_MIN = 0.25f       // drill screen ke is band me rehta hai
    const val DRILL_Y_MAX = 0.60f
    const val DANGER_DEPTH = 0.30f      // drill ke neeche itni height tak bomb "khatra"
    const val DANGER_HALF_WIDTH = 0.22f // drill ke left/right itni chaudai tak
    const val BOMB_MIN_PIXELS = 40      // kam se kam itne gray samples = bomb
    const val SWIPE_DX = 140f           // swipe kitna bada (px) - calibrate karo
    const val SWIPE_MS = 120L
    const val COOLDOWN_MS = 450L
    const val SWIPE_Y = 0.75f           // swipe kis height par (screen ka %)
}

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val thread = HandlerThread("digbot").apply { start() }
    private var lastDodge = 0L
    private var fullW = 0
    private var fullH = 0

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        showForeground()
        val code = intent.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data") ?: run { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(thread.looper))
        startCapture()
        return START_NOT_STICKY
    }

    private fun showForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "DigBot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bot")
            .setContentTitle("DigBot chal raha hai")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        fullW = dm.widthPixels; fullH = dm.heightPixels
        val rw = fullW / Cfg.SCALE; val rh = fullH / Cfg.SCALE
        reader = ImageReader.newInstance(rw, rh, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "digbot", rw, rh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try { process(img, rw, rh) } finally { img.close() }
        }, Handler(thread.looper))
    }

    private fun process(img: Image, w: Int, h: Int) {
        val plane = img.planes[0]
        val buf = plane.buffer
        val rs = plane.rowStride
        val ps = plane.pixelStride
        val st = Cfg.STEP

        // 1) Drill dhundo: orange pixels
        var dx = 0L; var dy = 0L; var dn = 0
        var y = (h * Cfg.DRILL_Y_MIN).toInt()
        val yEnd = (h * Cfg.DRILL_Y_MAX).toInt()
        while (y < yEnd) {
            var x = 0
            while (x < w) {
                val o = y * rs + x * ps
                val r = buf.get(o).toInt() and 255
                val g = buf.get(o + 1).toInt() and 255
                val b = buf.get(o + 2).toInt() and 255
                if (r > 220 && g in 90..175 && b < 70) { dx += x; dy += y; dn++ }
                x += st
            }
            y += st
        }
        if (dn < 8) return
        val drillX = (dx / dn).toInt()
        val drillY = (dy / dn).toInt()

        // 2) Bomb dhundo: drill ke neeche, gray/kala gol object
        val x0 = max(0, drillX - (w * Cfg.DANGER_HALF_WIDTH).toInt())
        val x1 = min(w - 1, drillX + (w * Cfg.DANGER_HALF_WIDTH).toInt())
        val y0 = drillY + (h * 0.04f).toInt()
        val y1 = min((h * 0.88f).toInt(), drillY + (h * Cfg.DANGER_DEPTH).toInt()) // ad banner ignore
        var bx = 0L; var bn = 0
        y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val o = y * rs + x * ps
                val r = buf.get(o).toInt() and 255
                val g = buf.get(o + 1).toInt() and 255
                val b = buf.get(o + 2).toInt() and 255
                val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
                if (mx - mn < 22 && mx in 15..130) { bx += x; bn++ }
                x += st
            }
            y += st
        }
        if (bn < Cfg.BOMB_MIN_PIXELS) return
        val bombX = (bx / bn).toInt()

        // 3) Dodge
        val now = System.currentTimeMillis()
        if (now - lastDodge < Cfg.COOLDOWN_MS) return
        var dir = if (bombX < drillX) 1 else -1        // bomb left me to right jao
        if (drillX < w * 0.2f) dir = 1
        if (drillX > w * 0.8f) dir = -1
        val sy = fullH * Cfg.SWIPE_Y
        val sx = fullW / 2f
        Log.d("DigBot", "bomb x=$bombX drill x=$drillX n=$bn dir=$dir")
        BotAccessibilityService.instance?.swipe(sx, sy, sx + dir * Cfg.SWIPE_DX, sy, Cfg.SWIPE_MS)
        lastDodge = now
    }

    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop(); thread.quitSafely()
        super.onDestroy()
    }
}
